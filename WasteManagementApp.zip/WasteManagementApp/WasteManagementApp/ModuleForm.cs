using System.Drawing;

namespace WasteManagementApp;

public class ModuleForm : Form
{
    public ModuleForm(string moduleName, string description)
    {
        Text = $"Waste Management | {moduleName}";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(640, 400);
        BackColor = Color.FromArgb(245, 248, 246);

        var title = new Label
        {
            Text = moduleName,
            Font = new Font("Segoe UI", 24, FontStyle.Bold),
            ForeColor = Color.FromArgb(25, 87, 65),
            AutoSize = true,
            Location = new Point(35, 35)
        };
        var details = new Label
        {
            Text = description,
            Font = new Font("Segoe UI", 11),
            ForeColor = Color.FromArgb(83, 99, 91),
            AutoSize = true,
            Location = new Point(38, 85)
        };
        var status = new Label
        {
            Text = "Module ready for implementation",
            Font = new Font("Segoe UI", 14, FontStyle.Bold),
            ForeColor = Color.FromArgb(45, 61, 52),
            AutoSize = true,
            Location = new Point(38, 160)
        };
        var closeButton = new Button
        {
            Text = "Close",
            Font = new Font("Segoe UI", 10, FontStyle.Bold),
            BackColor = Color.FromArgb(25, 87, 65),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Location = new Point(38, 300),
            Size = new Size(110, 38)
        };
        closeButton.FlatAppearance.BorderSize = 0;
        closeButton.Click += (_, _) => Close();

        Controls.AddRange([title, details, status, closeButton]);
    }
}
