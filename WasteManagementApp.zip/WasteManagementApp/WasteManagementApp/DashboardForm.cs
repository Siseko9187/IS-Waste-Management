using System.Drawing;

namespace WasteManagementApp;

public class DashboardForm : Form
{
    private readonly UserRole role;

    public DashboardForm(UserRole role)
    {
        this.role = role;
        Text = $"Waste Management | {GetRoleName(role)} Dashboard";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(980, 620);
        MinimumSize = new Size(820, 540);
        BackColor = Color.FromArgb(245, 248, 246);

        var header = new Panel
        {
            Dock = DockStyle.Top,
            Height = 126,
            BackColor = Color.FromArgb(25, 87, 65)
        };
        var title = new Label
        {
            Text = $"{GetRoleName(role)} Dashboard",
            Font = new Font("Segoe UI", 25, FontStyle.Bold),
            ForeColor = Color.White,
            AutoSize = true,
            Location = new Point(40, 25)
        };
        var welcome = new Label
        {
            Text = "Manage your waste collection responsibilities from one place.",
            Font = new Font("Segoe UI", 11),
            ForeColor = Color.FromArgb(216, 235, 224),
            AutoSize = true,
            Location = new Point(43, 73)
        };
        header.Controls.AddRange([title, welcome]);

        var navigation = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(40, 35, 40, 35),
            ColumnCount = 2,
            RowCount = (GetButtons(role).Length + 1) / 2,
            BackColor = Color.FromArgb(245, 248, 246)
        };
        navigation.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        navigation.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

        var buttons = GetButtons(role);
        for (var row = 0; row < navigation.RowCount; row++)
            navigation.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / navigation.RowCount));

        for (var index = 0; index < buttons.Length; index++)
        {
            var column = index % 2;
            var row = index / 2;
            AddNavigationButton(navigation, buttons[index].Name, column, row, buttons[index].Description, buttons[index].Name == "Logout");
        }

        Controls.Add(navigation);
        Controls.Add(header);
    }

    private static string GetRoleName(UserRole role) => role switch
    {
        UserRole.SystemAdministrator => "System Administrator",
        _ => role.ToString()
    };

    private static (string Name, string Description)[] GetButtons(UserRole role) => role switch
    {
        UserRole.Driver =>
        [
            ("My Schedule", "View assigned collection schedules."),
            ("Collection Details", "Review details for assigned collections."),
            ("Scan QR code", "Scan a collection point QR code."),
            ("My Completed Collections", "Review completed collection work."),
            ("Logout", "Return to the login page.")
        ],
        UserRole.Manager =>
        [
            ("Overview", "View collection operations at a glance."),
            ("Completed Collections", "Review completed collection activity."),
            ("Outstanding Collections", "Review collections still requiring action."),
            ("Reports", "Review operational performance reports."),
            ("Hourly Summary", "Review collection activity by hour."),
            ("Print Reports", "Prepare reports for printing."),
            ("Logout", "Return to the login page.")
        ],
        UserRole.SystemAdministrator =>
        [
            ("User Management", "Manage users and access permissions."),
            ("System Overview", "Review system status and activity."),
            ("Reports", "Review system and operational reports."),
            ("Logout", "Return to the login page.")
        ],
        _ =>
        [
            ("Collection Points", "View and maintain collection point locations."),
            ("Schedule Collection", "Create and manage collection schedules."),
            ("Assign Worker", "Assign workers to collection activities."),
            ("Record Collection", "Record completed collection activities."),
            ("Scan QR code", "Scan a collection point QR code."),
            ("Reports", "Review collection activity and performance reports."),
            ("Hourly Summary", "Review collection activity by hour."),
            ("Logout", "Return to the login page.")
        ]
    };

    private void AddNavigationButton(TableLayoutPanel layout, string text, int column, int row, string description, bool isExit = false)
    {
        var button = new Button
        {
            Text = text,
            Dock = DockStyle.Fill,
            Margin = new Padding(10),
            Font = new Font("Segoe UI", 12, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(24),
            BackColor = isExit ? Color.FromArgb(166, 61, 57) : Color.White,
            ForeColor = isExit ? Color.White : Color.FromArgb(25, 87, 65),
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand,
            UseCompatibleTextRendering = true
        };
        button.FlatAppearance.BorderColor = isExit ? Color.FromArgb(166, 61, 57) : Color.FromArgb(206, 220, 211);
        button.FlatAppearance.BorderSize = 1;
        button.Click += (_, _) =>
        {
            if (isExit)
            {
                Close();
                return;
            }

            using var moduleForm = new ModuleForm(text, description);
            moduleForm.ShowDialog(this);
        };
        layout.Controls.Add(button, column, row);
    }
}
