using System.Drawing;

namespace WasteManagementApp;

public class LoginForm : Form
{
    private readonly TextBox usernameTextBox = new();
    private readonly TextBox passwordTextBox = new();
    private readonly Label errorLabel = new();
    private static readonly Dictionary<string, (string Password, UserRole Role)> Users = new(StringComparer.OrdinalIgnoreCase)
    {
        ["driver"] = ("Driver123!", UserRole.Driver),
        ["staff"] = ("Staff123!", UserRole.Staff),
        ["manager"] = ("Manager123!", UserRole.Manager),
        ["admin"] = ("Admin123!", UserRole.SystemAdministrator)
    };

    public LoginForm()
    {
        Text = "Waste Management | Login";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(520, 390);
        MinimumSize = new Size(520, 390);
        BackColor = Color.FromArgb(245, 248, 246);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;

        var title = new Label
        {
            Text = "Waste Management",
            Font = new Font("Segoe UI", 24, FontStyle.Bold),
            ForeColor = Color.FromArgb(25, 87, 65),
            AutoSize = true,
            Location = new Point(42, 35)
        };

        var subtitle = new Label
        {
            Text = "Sign in to access your operations dashboard",
            Font = new Font("Segoe UI", 10),
            ForeColor = Color.FromArgb(83, 99, 91),
            AutoSize = true,
            Location = new Point(45, 82)
        };

        var usernameLabel = CreateLabel("Username", 45, 132);
        usernameTextBox.SetBounds(45, 155, 420, 32);
        usernameTextBox.Font = new Font("Segoe UI", 11);

        var passwordLabel = CreateLabel("Password", 45, 202);
        passwordTextBox.SetBounds(45, 225, 420, 32);
        passwordTextBox.Font = new Font("Segoe UI", 11);
        passwordTextBox.UseSystemPasswordChar = true;

        errorLabel.Text = "Invalid username or password.";
        errorLabel.Font = new Font("Segoe UI", 9);
        errorLabel.ForeColor = Color.FromArgb(166, 61, 57);
        errorLabel.AutoSize = true;
        errorLabel.Location = new Point(45, 270);
        errorLabel.Visible = false;

        var loginButton = new Button
        {
            Text = "Sign in",
            Font = new Font("Segoe UI", 10, FontStyle.Bold),
            BackColor = Color.FromArgb(25, 87, 65),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand
        };
        loginButton.SetBounds(345, 320, 120, 38);
        loginButton.FlatAppearance.BorderSize = 0;
        loginButton.Click += LoginButton_Click;

        Controls.AddRange([title, subtitle, usernameLabel, usernameTextBox, passwordLabel, passwordTextBox, errorLabel, loginButton]);
        AcceptButton = loginButton;
    }

    private static Label CreateLabel(string text, int x, int y) => new()
    {
        Text = text,
        Font = new Font("Segoe UI", 10, FontStyle.Bold),
        ForeColor = Color.FromArgb(45, 61, 52),
        AutoSize = true,
        Location = new Point(x, y)
    };

    private void LoginButton_Click(object? sender, EventArgs e)
    {
        if (!Users.TryGetValue(usernameTextBox.Text.Trim(), out var user) || user.Password != passwordTextBox.Text)
        {
            errorLabel.Visible = true;
            passwordTextBox.SelectAll();
            passwordTextBox.Focus();
            return;
        }

        errorLabel.Visible = false;
        Hide();
        using var dashboard = new DashboardForm(user.Role);
        dashboard.ShowDialog(this);
        ClearLoginFields();
        Show();
    }

    private void ClearLoginFields()
    {
        usernameTextBox.Clear();
        passwordTextBox.Clear();
        errorLabel.Visible = false;
        usernameTextBox.Focus();
    }
}

public enum UserRole
{
    Driver,
    Staff,
    Manager,
    SystemAdministrator
}
