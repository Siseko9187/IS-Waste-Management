# Waste Management App

A .NET 8 Windows Forms desktop application shell for managing waste operations.

## Current Features

- Login screen
- Dashboard navigation for Waste Collections, Collection Points, Admin, and Reports
- Exit button that returns to the login screen
- Placeholder forms ready for each module's implementation

## Development Login Credentials

| Role | Username | Password |
| --- | --- | --- |
| Driver | `driver` | `Driver123!` |
| Staff | `staff` | `Staff123!` |
| Manager | `manager` | `Manager123!` |
| System Administrator | `admin` | `Admin123!` |

## Run

From the project directory:

```powershell
& "C:\Program Files\dotnet\dotnet.exe" run
```

The application targets Windows and requires the .NET 8 SDK.
