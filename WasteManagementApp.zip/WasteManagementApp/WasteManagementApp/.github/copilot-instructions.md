# Waste Management App Instructions

- Target framework: .NET 8 Windows Forms.
- Keep dashboard navigation labels stable: Waste Collections, Collection Points, Admin, Reports, and Exit.
- Keep module screens independently replaceable as features are implemented.
- Validate changes with `dotnet build` from the project directory.
