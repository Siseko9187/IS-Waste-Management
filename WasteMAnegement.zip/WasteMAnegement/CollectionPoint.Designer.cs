﻿namespace WasteMAnegement
{
    partial class CollectionPoint
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlPlaceInfo = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddPlace = new System.Windows.Forms.Button();
            this.btnEditPlace = new System.Windows.Forms.Button();
            this.btnDeletePlace = new System.Windows.Forms.Button();
            this.dgvCollectionPlace = new System.Windows.Forms.DataGridView();
            this.CollectionAddPNL = new System.Windows.Forms.Panel();
            this.btnSve = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.txtRegion = new System.Windows.Forms.TextBox();
            this.lblRegion = new System.Windows.Forms.Label();
            this.txtSurburb = new System.Windows.Forms.TextBox();
            this.lblSurburbtype = new System.Windows.Forms.Label();
            this.lblSurburb = new System.Windows.Forms.Label();
            this.txtPCode = new System.Windows.Forms.TextBox();
            this.lblPostalCode = new System.Windows.Forms.Label();
            this.cmbTypeLocation = new System.Windows.Forms.ComboBox();
            this.pnlPlaceInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCollectionPlace)).BeginInit();
            this.CollectionAddPNL.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlPlaceInfo
            // 
            this.pnlPlaceInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(87)))), ((int)(((byte)(65)))));
            this.pnlPlaceInfo.Controls.Add(this.label1);
            this.pnlPlaceInfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlPlaceInfo.Location = new System.Drawing.Point(0, 0);
            this.pnlPlaceInfo.Name = "pnlPlaceInfo";
            this.pnlPlaceInfo.Size = new System.Drawing.Size(800, 57);
            this.pnlPlaceInfo.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(248, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Colletion Point Management Information ";
            // 
            // btnAddPlace
            // 
            this.btnAddPlace.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnAddPlace.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddPlace.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAddPlace.Location = new System.Drawing.Point(254, 72);
            this.btnAddPlace.Name = "btnAddPlace";
            this.btnAddPlace.Size = new System.Drawing.Size(75, 33);
            this.btnAddPlace.TabIndex = 6;
            this.btnAddPlace.Text = "Add User";
            this.btnAddPlace.UseVisualStyleBackColor = false;
            this.btnAddPlace.Click += new System.EventHandler(this.btnAddPlace_Click);
            // 
            // btnEditPlace
            // 
            this.btnEditPlace.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnEditPlace.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditPlace.Location = new System.Drawing.Point(363, 72);
            this.btnEditPlace.Name = "btnEditPlace";
            this.btnEditPlace.Size = new System.Drawing.Size(75, 33);
            this.btnEditPlace.TabIndex = 7;
            this.btnEditPlace.Text = "Edit ";
            this.btnEditPlace.UseVisualStyleBackColor = false;
            this.btnEditPlace.Click += new System.EventHandler(this.btnEditPlace_Click);
            // 
            // btnDeletePlace
            // 
            this.btnDeletePlace.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnDeletePlace.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeletePlace.Location = new System.Drawing.Point(452, 72);
            this.btnDeletePlace.Name = "btnDeletePlace";
            this.btnDeletePlace.Size = new System.Drawing.Size(75, 33);
            this.btnDeletePlace.TabIndex = 8;
            this.btnDeletePlace.Text = "Delete";
            this.btnDeletePlace.UseVisualStyleBackColor = false;
            this.btnDeletePlace.Click += new System.EventHandler(this.btnDeletePlace_Click);
            // 
            // dgvCollectionPlace
            // 
            this.dgvCollectionPlace.AllowUserToAddRows = false;
            this.dgvCollectionPlace.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvCollectionPlace.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCollectionPlace.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.DisplayedCells;
            this.dgvCollectionPlace.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCollectionPlace.Location = new System.Drawing.Point(0, 133);
            this.dgvCollectionPlace.Name = "dgvCollectionPlace";
            this.dgvCollectionPlace.Size = new System.Drawing.Size(800, 388);
            this.dgvCollectionPlace.TabIndex = 9;
            // 
            // CollectionAddPNL
            // 
            this.CollectionAddPNL.Controls.Add(this.cmbTypeLocation);
            this.CollectionAddPNL.Controls.Add(this.btnSve);
            this.CollectionAddPNL.Controls.Add(this.btnCancel);
            this.CollectionAddPNL.Controls.Add(this.txtRegion);
            this.CollectionAddPNL.Controls.Add(this.lblRegion);
            this.CollectionAddPNL.Controls.Add(this.txtSurburb);
            this.CollectionAddPNL.Controls.Add(this.lblSurburbtype);
            this.CollectionAddPNL.Controls.Add(this.lblSurburb);
            this.CollectionAddPNL.Controls.Add(this.txtPCode);
            this.CollectionAddPNL.Controls.Add(this.lblPostalCode);
            this.CollectionAddPNL.Location = new System.Drawing.Point(198, 165);
            this.CollectionAddPNL.Name = "CollectionAddPNL";
            this.CollectionAddPNL.Size = new System.Drawing.Size(469, 309);
            this.CollectionAddPNL.TabIndex = 11;
            // 
            // btnSve
            // 
            this.btnSve.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnSve.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSve.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSve.Location = new System.Drawing.Point(106, 229);
            this.btnSve.Name = "btnSve";
            this.btnSve.Size = new System.Drawing.Size(75, 33);
            this.btnSve.TabIndex = 10;
            this.btnSve.Text = "Save";
            this.btnSve.UseVisualStyleBackColor = false;
            this.btnSve.Click += new System.EventHandler(this.btnSve_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCancel.Location = new System.Drawing.Point(238, 229);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 33);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // txtRegion
            // 
            this.txtRegion.Location = new System.Drawing.Point(119, 104);
            this.txtRegion.Multiline = true;
            this.txtRegion.Name = "txtRegion";
            this.txtRegion.Size = new System.Drawing.Size(280, 25);
            this.txtRegion.TabIndex = 8;
            // 
            // lblRegion
            // 
            this.lblRegion.AutoSize = true;
            this.lblRegion.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegion.ForeColor = System.Drawing.Color.Black;
            this.lblRegion.Location = new System.Drawing.Point(10, 112);
            this.lblRegion.Name = "lblRegion";
            this.lblRegion.Size = new System.Drawing.Size(53, 17);
            this.lblRegion.TabIndex = 7;
            this.lblRegion.Text = "Region:";
            // 
            // txtSurburb
            // 
            this.txtSurburb.Location = new System.Drawing.Point(119, 62);
            this.txtSurburb.Multiline = true;
            this.txtSurburb.Name = "txtSurburb";
            this.txtSurburb.Size = new System.Drawing.Size(280, 25);
            this.txtSurburb.TabIndex = 5;
            // 
            // lblSurburbtype
            // 
            this.lblSurburbtype.AutoSize = true;
            this.lblSurburbtype.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSurburbtype.ForeColor = System.Drawing.Color.Black;
            this.lblSurburbtype.Location = new System.Drawing.Point(10, 153);
            this.lblSurburbtype.Name = "lblSurburbtype";
            this.lblSurburbtype.Size = new System.Drawing.Size(98, 17);
            this.lblSurburbtype.TabIndex = 3;
            this.lblSurburbtype.Text = "Location Type :";
            // 
            // lblSurburb
            // 
            this.lblSurburb.AutoSize = true;
            this.lblSurburb.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSurburb.ForeColor = System.Drawing.Color.Black;
            this.lblSurburb.Location = new System.Drawing.Point(10, 70);
            this.lblSurburb.Name = "lblSurburb";
            this.lblSurburb.Size = new System.Drawing.Size(64, 17);
            this.lblSurburb.TabIndex = 2;
            this.lblSurburb.Text = "Surburb :";
            // 
            // txtPCode
            // 
            this.txtPCode.Location = new System.Drawing.Point(119, 15);
            this.txtPCode.Multiline = true;
            this.txtPCode.Name = "txtPCode";
            this.txtPCode.Size = new System.Drawing.Size(280, 25);
            this.txtPCode.TabIndex = 1;
            // 
            // lblPostalCode
            // 
            this.lblPostalCode.AutoSize = true;
            this.lblPostalCode.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPostalCode.ForeColor = System.Drawing.Color.Black;
            this.lblPostalCode.Location = new System.Drawing.Point(10, 23);
            this.lblPostalCode.Name = "lblPostalCode";
            this.lblPostalCode.Size = new System.Drawing.Size(87, 17);
            this.lblPostalCode.TabIndex = 0;
            this.lblPostalCode.Text = "Postal Code: ";
            // 
            // cmbTypeLocation
            // 
            this.cmbTypeLocation.FormattingEnabled = true;
            this.cmbTypeLocation.Items.AddRange(new object[] {
            "Commercial",
            "Industry",
            "Residential"});
            this.cmbTypeLocation.Location = new System.Drawing.Point(119, 153);
            this.cmbTypeLocation.Name = "cmbTypeLocation";
            this.cmbTypeLocation.Size = new System.Drawing.Size(280, 21);
            this.cmbTypeLocation.TabIndex = 15;
            // 
            // CollectionPoint
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 497);
            this.Controls.Add(this.CollectionAddPNL);
            this.Controls.Add(this.dgvCollectionPlace);
            this.Controls.Add(this.btnDeletePlace);
            this.Controls.Add(this.btnEditPlace);
            this.Controls.Add(this.btnAddPlace);
            this.Controls.Add(this.pnlPlaceInfo);
            this.Name = "CollectionPoint";
            this.Text = "CollectionPoint";
            this.pnlPlaceInfo.ResumeLayout(false);
            this.pnlPlaceInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCollectionPlace)).EndInit();
            this.CollectionAddPNL.ResumeLayout(false);
            this.CollectionAddPNL.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlPlaceInfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddPlace;
        private System.Windows.Forms.Button btnEditPlace;
        private System.Windows.Forms.Button btnDeletePlace;
        private System.Windows.Forms.DataGridView dgvCollectionPlace;
        private System.Windows.Forms.Panel CollectionAddPNL;
        private System.Windows.Forms.Button btnSve;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox txtRegion;
        private System.Windows.Forms.Label lblRegion;
        private System.Windows.Forms.TextBox txtSurburb;
        private System.Windows.Forms.Label lblSurburbtype;
        private System.Windows.Forms.Label lblSurburb;
        private System.Windows.Forms.TextBox txtPCode;
        private System.Windows.Forms.Label lblPostalCode;
        private System.Windows.Forms.ComboBox cmbTypeLocation;
    }
}