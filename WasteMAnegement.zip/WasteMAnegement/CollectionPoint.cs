﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WasteMAnegement
{
    public partial class CollectionPoint : Form
    {
        private bool isEditMode = false;
        private BindingList<CollectionPlace> Places = new BindingList<CollectionPlace>();

        public CollectionPoint()
        {
            InitializeComponent();

            ToggleCollectionPanel(visible: false);

            dgvCollectionPlace.DataSource = Places;
        }

        private void ToggleCollectionPanel(bool visible)

        {
            CollectionAddPNL.Visible = visible;

            btnAddPlace.Enabled = !visible;
            btnEditPlace.Enabled = !visible;
            btnDeletePlace.Enabled = !visible;

            if (!visible)
            {
                ClearInputFields();
            }

        }
        private void ClearInputFields()
        {
            txtPCode.Clear();
            txtSurburb.Clear();
            txtRegion.Clear();
            cmbTypeLocation.SelectedIndex = -1; // Clears the ComboBox selection if you have one
        }

        private void btnAddPlace_Click(object sender, EventArgs e)
        {
            isEditMode = false;
            ToggleCollectionPanel(visible: true); // Tapping reveals UserAddPNL
            txtPCode.Focus();
        }

        private void btnEditPlace_Click(object sender, EventArgs e)
        {
            isEditMode = true;
            ToggleCollectionPanel(visible: true);
        }

        private void btnDeletePlace_Click(object sender, EventArgs e)
        {
            if (dgvCollectionPlace.CurrentRow == null) return;

            var result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                CollectionPlace selectedRecord = (CollectionPlace)dgvCollectionPlace.CurrentRow.DataBoundItem;
                Places.Remove(selectedRecord);
            }
        }

        private void btnSve_Click(object sender, EventArgs e)
        {
            // 1. Basic check: Don't allow blank IDs or Passwords
            if (string.IsNullOrWhiteSpace(txtPCode.Text) || string.IsNullOrWhiteSpace(txtSurburb.Text))
            {
                MessageBox.Show("User ID and Password cannot be blank.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (isEditMode)
            {
                // 2. EDIT MODE: Find the row currently highlighted in your grid view
                if (dgvCollectionPlace.CurrentRow != null)
                {
                    // Get the live data object bound to that specific row
                    CollectionPlace selectedRecord = (CollectionPlace)dgvCollectionPlace.CurrentRow.DataBoundItem;

                    // Overwrite its values with whatever you typed into the fields
                    selectedRecord.Surburb = txtSurburb.Text;
                    selectedRecord.Region = txtRegion.Text;
                    selectedRecord.Postal_Code = txtPCode.Text;
                    selectedRecord.Location_Type = cmbTypeLocation.SelectedItem?.ToString() ?? "User";

                    // Force the grid UI view to visually repaint itself with the changes
                    dgvCollectionPlace.Refresh();

                    MessageBox.Show("User updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                // 3. ADD MODE: Create a brand new WasteRecord object from your input boxes
                CollectionPlace newRecord = new CollectionPlace
                {
                    Surburb = txtSurburb.Text,
                    Region = txtRegion.Text,
                    Postal_Code = txtPCode.Text,
                    Location_Type = cmbTypeLocation.SelectedItem?.ToString() ?? "User"
                };

                // Add it directly into your live list (the DataGridView will show it instantly)
                Places.Add(newRecord);

                MessageBox.Show("New user added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // Tucks UserAddPNL completely back out of view when done
            ToggleCollectionPanel(visible: false);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ToggleCollectionPanel(visible: false); // Dismisses UserAddPNL immediately without saving
        }
    }
}
