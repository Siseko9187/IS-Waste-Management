﻿namespace WasteMAnegement
{
    partial class DashboardForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnUserManage = new System.Windows.Forms.Button();
            this.btnScanQR = new System.Windows.Forms.Button();
            this.btnAssignDrvr = new System.Windows.Forms.Button();
            this.btnHourlySum = new System.Windows.Forms.Button();
            this.BtnPrint = new System.Windows.Forms.Button();
            this.btnRecord = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnCollection = new System.Windows.Forms.Button();
            this.btnCompleted = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnOverview = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblClerkDash = new System.Windows.Forms.Label();
            this.lblManagerDash = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblAdmintittle = new System.Windows.Forms.Label();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Controls.Add(this.btnUserManage);
            this.flowLayoutPanel1.Controls.Add(this.btnScanQR);
            this.flowLayoutPanel1.Controls.Add(this.btnAssignDrvr);
            this.flowLayoutPanel1.Controls.Add(this.btnHourlySum);
            this.flowLayoutPanel1.Controls.Add(this.BtnPrint);
            this.flowLayoutPanel1.Controls.Add(this.btnRecord);
            this.flowLayoutPanel1.Controls.Add(this.btnReport);
            this.flowLayoutPanel1.Controls.Add(this.btnCollection);
            this.flowLayoutPanel1.Controls.Add(this.btnCompleted);
            this.flowLayoutPanel1.Controls.Add(this.btnLogout);
            this.flowLayoutPanel1.Controls.Add(this.btnOverview);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 152);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(40);
            this.flowLayoutPanel1.Size = new System.Drawing.Size(800, 460);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // btnUserManage
            // 
            this.btnUserManage.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUserManage.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnUserManage.Location = new System.Drawing.Point(55, 55);
            this.btnUserManage.Margin = new System.Windows.Forms.Padding(15);
            this.btnUserManage.Name = "btnUserManage";
            this.btnUserManage.Size = new System.Drawing.Size(260, 80);
            this.btnUserManage.TabIndex = 21;
            this.btnUserManage.Text = "  User Management";
            this.btnUserManage.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUserManage.UseVisualStyleBackColor = true;
            this.btnUserManage.Click += new System.EventHandler(this.btnUserManage_Click);
            // 
            // btnScanQR
            // 
            this.btnScanQR.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnScanQR.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnScanQR.Location = new System.Drawing.Point(345, 55);
            this.btnScanQR.Margin = new System.Windows.Forms.Padding(15);
            this.btnScanQR.Name = "btnScanQR";
            this.btnScanQR.Size = new System.Drawing.Size(260, 80);
            this.btnScanQR.TabIndex = 20;
            this.btnScanQR.Text = "  Scan QR code";
            this.btnScanQR.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnScanQR.UseVisualStyleBackColor = true;
            // 
            // btnAssignDrvr
            // 
            this.btnAssignDrvr.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAssignDrvr.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnAssignDrvr.Location = new System.Drawing.Point(55, 165);
            this.btnAssignDrvr.Margin = new System.Windows.Forms.Padding(15);
            this.btnAssignDrvr.Name = "btnAssignDrvr";
            this.btnAssignDrvr.Size = new System.Drawing.Size(260, 80);
            this.btnAssignDrvr.TabIndex = 19;
            this.btnAssignDrvr.Text = " Assign Driver";
            this.btnAssignDrvr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAssignDrvr.UseVisualStyleBackColor = true;
            this.btnAssignDrvr.Click += new System.EventHandler(this.btnAssignDrvr_Click);
            // 
            // btnHourlySum
            // 
            this.btnHourlySum.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHourlySum.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnHourlySum.Location = new System.Drawing.Point(345, 165);
            this.btnHourlySum.Margin = new System.Windows.Forms.Padding(15);
            this.btnHourlySum.Name = "btnHourlySum";
            this.btnHourlySum.Size = new System.Drawing.Size(260, 80);
            this.btnHourlySum.TabIndex = 18;
            this.btnHourlySum.Text = "Hourly Summary";
            this.btnHourlySum.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHourlySum.UseVisualStyleBackColor = true;
            // 
            // BtnPrint
            // 
            this.BtnPrint.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnPrint.ForeColor = System.Drawing.Color.DarkGreen;
            this.BtnPrint.Location = new System.Drawing.Point(55, 275);
            this.BtnPrint.Margin = new System.Windows.Forms.Padding(15);
            this.BtnPrint.Name = "BtnPrint";
            this.BtnPrint.Size = new System.Drawing.Size(260, 80);
            this.BtnPrint.TabIndex = 16;
            this.BtnPrint.Text = "  Print Reports";
            this.BtnPrint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnPrint.UseVisualStyleBackColor = true;
            // 
            // btnRecord
            // 
            this.btnRecord.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecord.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnRecord.Location = new System.Drawing.Point(345, 275);
            this.btnRecord.Margin = new System.Windows.Forms.Padding(15);
            this.btnRecord.Name = "btnRecord";
            this.btnRecord.Size = new System.Drawing.Size(260, 80);
            this.btnRecord.TabIndex = 15;
            this.btnRecord.Text = "  Record Collection";
            this.btnRecord.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRecord.UseVisualStyleBackColor = true;
            // 
            // btnReport
            // 
            this.btnReport.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnReport.Location = new System.Drawing.Point(55, 385);
            this.btnReport.Margin = new System.Windows.Forms.Padding(15);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(260, 80);
            this.btnReport.TabIndex = 14;
            this.btnReport.Text = "  Report";
            this.btnReport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReport.UseVisualStyleBackColor = true;
            // 
            // btnCollection
            // 
            this.btnCollection.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCollection.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnCollection.Location = new System.Drawing.Point(345, 385);
            this.btnCollection.Margin = new System.Windows.Forms.Padding(15);
            this.btnCollection.Name = "btnCollection";
            this.btnCollection.Size = new System.Drawing.Size(260, 80);
            this.btnCollection.TabIndex = 13;
            this.btnCollection.Text = "  Collection Points";
            this.btnCollection.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCollection.UseVisualStyleBackColor = true;
            this.btnCollection.Click += new System.EventHandler(this.btnCollection_Click);
            // 
            // btnCompleted
            // 
            this.btnCompleted.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompleted.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnCompleted.Location = new System.Drawing.Point(55, 495);
            this.btnCompleted.Margin = new System.Windows.Forms.Padding(15);
            this.btnCompleted.Name = "btnCompleted";
            this.btnCompleted.Size = new System.Drawing.Size(260, 80);
            this.btnCompleted.TabIndex = 12;
            this.btnCompleted.Text = "  Completed Collection";
            this.btnCompleted.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCompleted.UseVisualStyleBackColor = true;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.Brown;
            this.btnLogout.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogout.ForeColor = System.Drawing.Color.Transparent;
            this.btnLogout.Location = new System.Drawing.Point(345, 495);
            this.btnLogout.Margin = new System.Windows.Forms.Padding(15);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(260, 80);
            this.btnLogout.TabIndex = 17;
            this.btnLogout.Text = "  Logout";
            this.btnLogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogout.UseVisualStyleBackColor = false;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // btnOverview
            // 
            this.btnOverview.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOverview.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnOverview.Location = new System.Drawing.Point(55, 605);
            this.btnOverview.Margin = new System.Windows.Forms.Padding(15);
            this.btnOverview.Name = "btnOverview";
            this.btnOverview.Size = new System.Drawing.Size(260, 80);
            this.btnOverview.TabIndex = 11;
            this.btnOverview.Text = "  Overview";
            this.btnOverview.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOverview.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(87)))), ((int)(((byte)(65)))));
            this.panel1.Controls.Add(this.lblClerkDash);
            this.panel1.Controls.Add(this.lblManagerDash);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblAdmintittle);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 100);
            this.panel1.TabIndex = 1;
            // 
            // lblClerkDash
            // 
            this.lblClerkDash.AutoSize = true;
            this.lblClerkDash.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblClerkDash.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblClerkDash.Location = new System.Drawing.Point(35, 26);
            this.lblClerkDash.Name = "lblClerkDash";
            this.lblClerkDash.Size = new System.Drawing.Size(262, 32);
            this.lblClerkDash.TabIndex = 3;
            this.lblClerkDash.Text = "Staff Clerk Dashboard";
            // 
            // lblManagerDash
            // 
            this.lblManagerDash.AutoSize = true;
            this.lblManagerDash.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblManagerDash.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblManagerDash.Location = new System.Drawing.Point(35, 26);
            this.lblManagerDash.Name = "lblManagerDash";
            this.lblManagerDash.Size = new System.Drawing.Size(247, 32);
            this.lblManagerDash.TabIndex = 2;
            this.lblManagerDash.Text = "Manager Dashboard";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(37, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(321, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Manage your responsibilities from one place.";
            // 
            // lblAdmintittle
            // 
            this.lblAdmintittle.AutoSize = true;
            this.lblAdmintittle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAdmintittle.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblAdmintittle.Location = new System.Drawing.Point(31, 22);
            this.lblAdmintittle.Name = "lblAdmintittle";
            this.lblAdmintittle.Size = new System.Drawing.Size(392, 32);
            this.lblAdmintittle.TabIndex = 0;
            this.lblAdmintittle.Text = "System Administrator Dashboard";
            // 
            // DashboardForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 612);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Name = "DashboardForm";
            this.Text = "DashboardForm";
            this.Load += new System.EventHandler(this.DashboardForm_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnUserManage;
        private System.Windows.Forms.Button btnScanQR;
        private System.Windows.Forms.Button btnAssignDrvr;
        private System.Windows.Forms.Button btnHourlySum;
        private System.Windows.Forms.Button btnLogout;
        private System.Windows.Forms.Button BtnPrint;
        private System.Windows.Forms.Button btnRecord;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Button btnCollection;
        private System.Windows.Forms.Button btnCompleted;
        private System.Windows.Forms.Button btnOverview;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblAdmintittle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblManagerDash;
        private System.Windows.Forms.Label lblClerkDash;
    }
}