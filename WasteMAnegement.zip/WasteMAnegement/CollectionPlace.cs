﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WasteMAnegement
{
    internal class CollectionPlace
    {

        public string Postal_Code { get; set; }
        public string Surburb { get; set; } // e.g., "North Gate Hub"
        public string Region { get; set; }

        public string Location_Type { get; set; }
    }
}
