﻿using System;

namespace WasteMAnegement
{
    internal class UserPerson
    {
        public string UserId { get; set; }
        public string Username { get; set; }
        public string Surname { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }
    }

    partial class Driver : UserPerson
    {
        
        public string Address { get; set; }
        public string Contact { get; set; }

        // Every time a new Driver object is built, it automatically assigns its own Role
        public Driver()
        {
            Role = "Driver";
        }
    }

}