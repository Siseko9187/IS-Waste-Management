﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WasteMAnegement
{
    public partial class Drivers : Form
    {
        private bool isEditMode = false;

        private BindingList<Driver> userList = new BindingList<Driver>();
        public Drivers()
        {
            InitializeComponent();

            ToggleDriverPanel(visible: false);

            dgvDriver.DataSource = userList;
        }

        private void ToggleDriverPanel(bool visible)
        {
            // Show or hide your custom panel based on button taps
            DriverAddPNL.Visible = visible;

            // Optional best practice: Freeze top buttons while editing 
            // so users don't accidentally tap "Add User" while already modifying a form
            btnAddUser.Enabled = !visible;
            btnEdit.Enabled = !visible;
            btnDelete.Enabled = !visible;
            btnRefresh.Enabled = !visible;

            if (!visible)
            {
                ClearInputFields();
            }
        }

        private void ClearInputFields()
        {
            txtDriverID.Clear();
            txtPassword.Clear();
            txtUsername.Clear();
            txtSurname.Clear();
            txtAddress.Clear();
            txtContacts.Clear();
            
        }

        private void btnAddUser_Click(object sender, EventArgs e)
        {
            isEditMode = false;
            ToggleDriverPanel(visible: true); // Tapping reveals UserAddPNL
            txtDriverID.Focus();             // Moves typing cursor to the first box
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            // (Optional: Load your selected user data here first)

            isEditMode = true;
            ToggleDriverPanel(visible: true); // Tapping reveals UserAddPNL loaded with details

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvDriver.CurrentRow == null) return;

            var result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Driver selectedRecord = (Driver)dgvDriver.CurrentRow.DataBoundItem;
                userList.Remove(selectedRecord);
            }
        }

        private void btnSve_Click(object sender, EventArgs e)
        {
            // 1. Basic check: Don't allow blank IDs or Passwords
            if (string.IsNullOrWhiteSpace(txtDriverID.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("User ID and Password cannot be blank.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (isEditMode)
            {
                // 2. EDIT MODE: Find the row currently highlighted in your grid view
                if (dgvDriver.CurrentRow != null)
                {
                    // Get the live data object bound to that specific row
                    Driver selectedRecord = (Driver)dgvDriver.CurrentRow.DataBoundItem;

                    // Overwrite its values with whatever you typed into the fields
                    selectedRecord.Username = txtUsername.Text;
                    selectedRecord.Password = txtPassword.Text;
                    selectedRecord.Address = txtAddress.Text;
                    selectedRecord.Contact = txtContacts.Text;
                    selectedRecord.UserId = txtDriverID.Text;
                    selectedRecord.Surname = txtSurname.Text;


                   

                    // Force the grid UI view to visually repaint itself with the changes
                    dgvDriver.Refresh();

                    MessageBox.Show("User updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                // 3. ADD MODE: Create a brand new WasteRecord object from your input boxes
                Driver newRecord = new Driver
                {
                    UserId = txtDriverID.Text,
                    Username = txtUsername.Text,
                    Password = txtPassword.Text,
                    Surname = txtSurname.Text,
                    Address = txtAddress.Text,
                    Contact = txtContacts.Text,
                    
                };

                // Add it directly into your live list (the DataGridView will show it instantly)
                userList.Add(newRecord);

                MessageBox.Show("New user added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // Tucks UserAddPNL completely back out of view when done
            ToggleDriverPanel(visible: false);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ToggleDriverPanel(visible: false); // Dismisses UserAddPNL immediately without saving
        }
    }
}

