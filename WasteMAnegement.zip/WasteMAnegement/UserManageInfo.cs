﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WasteMAnegement
{
    public partial class UserManagePNL : Form
    {
        // Tracks if the current operation is an Edit (true) or Add (false)
        private bool isEditMode = false;

        // This special list automatically syncs up with your DataGridView UI
        private BindingList<UserPerson> userList = new BindingList<UserPerson>();


        public UserManagePNL()
        {
            InitializeComponent();

            // Keeps UserAddPNL completely hidden when the app first opens
            ToggleUserPanel(visible: false);

            // Bind your live user list to your screen grid view
            dgvUser.DataSource = userList;

            // (Optional) Add a dummy user just so you can test if it shows up immediately
            //userList.Add(new WasteRecord { UserId = "admin", Username = "System Admin", Password = "123", Role = "Admin" });

        }

        private void ToggleUserPanel(bool visible)
        {
            // Show or hide your custom panel based on button taps
            UserAddPNL.Visible = visible;

            // Optional best practice: Freeze top buttons while editing 
            // so users don't accidentally tap "Add User" while already modifying a form
            btnAddUser.Enabled = !visible;
            btnEdit.Enabled = !visible;
            btnDelete.Enabled = !visible;
            btnRefresh.Enabled = !visible;

            if (!visible)
            {
                ClearInputFields();
            }
        }

        private void ClearInputFields()
        {
            txtID.Clear();
            txtPassword.Clear();
            txtUsername.Clear();
            txtSurname.Clear();
            cmbRoles.SelectedIndex = -1; // Clears the ComboBox selection if you have one
        }
        // ==========================================
        // TOP ACTION BUTTONS (Tapping triggers the panel)
        // ==========================================
        private void btnAddUser_Click_1(object sender, EventArgs e)
        {
            isEditMode = false;
            ToggleUserPanel(visible: true); // Tapping reveals UserAddPNL
            txtID.Focus();             // Moves typing cursor to the first box
        }

        private void btnEdit_Click_1(object sender, EventArgs e)
        {
            // (Optional: Load your selected user data here first)

            isEditMode = true;
            ToggleUserPanel(visible: true); // Tapping reveals UserAddPNL loaded with details
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvUser.CurrentRow == null) return;

            var result = MessageBox.Show("Are you sure you want to delete this record?", "Confirm", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                UserPerson selectedRecord = (UserPerson)dgvUser.CurrentRow.DataBoundItem;
                userList.Remove(selectedRecord);
            }
        }
        

        // ==========================================
        // PANEL BUTTONS (Tapping hides the panel)
        // ==========================================

        private void btnSve_Click(object sender, EventArgs e)
        {
            // 1. Basic check: Don't allow blank IDs or Passwords
            if (string.IsNullOrWhiteSpace(txtID.Text) || string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("User ID and Password cannot be blank.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (isEditMode)
            {
                // 2. EDIT MODE: Find the row currently highlighted in your grid view
                if (dgvUser.CurrentRow != null)
                {
                    // Get the live data object bound to that specific row
                    UserPerson selectedRecord = (UserPerson)dgvUser.CurrentRow.DataBoundItem;

                    // Overwrite its values with whatever you typed into the fields
                    selectedRecord.Username = txtUsername.Text;
                    selectedRecord.Password = txtPassword.Text;
                    selectedRecord.Surname = txtSurname.Text;
                    selectedRecord.UserId = txtID.Text;
                    selectedRecord.Role = cmbRoles.SelectedItem?.ToString() ?? "User";

                    // Force the grid UI view to visually repaint itself with the changes
                    dgvUser.Refresh();

                    MessageBox.Show("User updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                // 3. ADD MODE: Create a brand new WasteRecord object from your input boxes
                UserPerson newRecord = new UserPerson
                {
                    UserId = txtID.Text,
                    Username = txtUsername.Text,
                    Surname  =txtSurname.Text,
                    Password = txtPassword.Text,
                    Role = cmbRoles.SelectedItem?.ToString() ?? "User"
                };

                // Add it directly into your live list (the DataGridView will show it instantly)
                userList.Add(newRecord);

                MessageBox.Show("New user added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // Tucks UserAddPNL completely back out of view when done
            ToggleUserPanel(visible: false);
        }

        private void btnCancel_Click_1(object sender, EventArgs e)
        {
            ToggleUserPanel(visible: false); // Dismisses UserAddPNL immediately without saving
        }

        
    }
}

