﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WasteMAnegement;

namespace WasteMAnegement
{
    public partial class Form1 : Form
    {

        private static readonly Dictionary<string, (string Password, UserRole Role)> Users = new Dictionary<string, (string Password, UserRole Role)>(StringComparer.OrdinalIgnoreCase)
        {
            //["driver"] = ("Driver123!", UserRole.Driver),
            ["staff"] = ("Staff123!", UserRole.Staff),
            ["manager"] = ("Manager123!", UserRole.Manager),
            ["admin"] = ("Admin123!", UserRole.SystemAdministrator)
        };


        public Form1()
        {
            InitializeComponent();

            // Set the password masking for the text box you dragged onto your form
            txtPassword.UseSystemPasswordChar = true;

            // Make sure the error label starts hidden when the application opens
            errorLabel.Visible = false;
        }

        private void btnSignin_Click_1(object sender, EventArgs e)
        {
            // Added the opening curly brace '{' at the end of the line below
            if (!Users.TryGetValue(txtUsername.Text.Trim(), out var user) || user.Password != txtPassword.Text)
            {
                errorLabel.Visible = true;
                txtPassword.SelectAll();
                txtPassword.Focus();
                return;
            }

            errorLabel.Visible = false;
            this.Hide();

            using (DashboardForm dashboard = new DashboardForm(user.Role))
            {
                dashboard.ShowDialog(this);
            }


            this.Show();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();
            errorLabel.Visible = false;
            txtUsername.Focus();
        }
    }

    public enum UserRole
    {
        Driver,
        Staff,
        Manager,
        SystemAdministrator
    }
}

