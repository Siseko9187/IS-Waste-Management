﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WasteMAnegement;

namespace WasteMAnegement
{
    public partial class DashboardForm : Form
    {
        private UserRole role;

        public DashboardForm()
        {
            InitializeComponent();
        }

        // FIXED: Added InitializeComponent() here so your design loads correctly!
        public DashboardForm(UserRole role)
        {
            InitializeComponent();
            this.role = role;
        }

        private void DashboardForm_Load(object sender, EventArgs e)
        {
            // 1. First, hide all role-specific buttons by default
            btnUserManage.Visible = false;
            btnScanQR.Visible = false;
            btnHourlySum.Visible = false;
            btnAssignDrvr.Visible = false;
            btnCollection.Visible = false;
            btnCompleted.Visible = false;
            btnLogout.Visible = true; // Set this to true by default so everyone can log out!
            btnRecord.Visible = false;
            BtnPrint.Visible = false;
            btnOverview.Visible = false;
            btnReport.Visible = false;
            lblAdmintittle.Visible = false;
            lblClerkDash.Visible = false;
            lblManagerDash.Visible = false;

            // 2. Show only the buttons that match the logged-in role
            switch (this.role)
            {
                case UserRole.Driver:
                    this.Text = "Waste Management | Driver Dashboard";
                    btnCollection.Visible = true;
                    btnScanQR.Visible = true;
                    btnCompleted.Visible = true;
                    break;

                case UserRole.Manager:
                    this.Text = "Waste Management | Manager Dashboard";
                    btnHourlySum.Visible = true;
                    btnReport.Visible = true;
                    btnOverview.Visible = true;
                    BtnPrint.Visible = true;
                    lblManagerDash.Visible = true;
                    break;

                case UserRole.SystemAdministrator:
                    this.Text = "Waste Management | Admin Dashboard";
                    btnUserManage.Visible = true;
                    btnReport.Visible = true;
                    btnRecord.Visible = true;
                    btnOverview.Visible = true;
                    lblAdmintittle.Visible = true;
                    break;

                case UserRole.Staff:
                    this.Text = "Waste Management | Staff Dashboard";
                    btnHourlySum.Visible = true;
                    btnAssignDrvr.Visible = true;
                    btnCollection.Visible = true;
                    btnCompleted.Visible = true;
                    btnRecord.Visible = true;
                    btnOverview.Visible = true;
                    btnReport.Visible = true;
                    btnScanQR.Visible = true;
                    lblClerkDash.Visible = true;
                    break;
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            using (Form1 form = new Form1())
            {

                this.Hide();

                form.ShowDialog(this);

            }
        }

        private void btnUserManage_Click(object sender, EventArgs e)
        {
            // 1. Create an instance of your UserManagePNL form
            UserManagePNL manageForm = new UserManagePNL();

            // 2. Display the form on screen
            manageForm.Show();

            // Optional: If you want to hide the current dashboard form while managing users, uncomment the line below:
            this.Hide(); 
        }

        private void btnAssignDrvr_Click(object sender, EventArgs e)
        {
            Drivers DriversForm = new Drivers();

            DriversForm.Show();

            this.Hide();
        }

        private void btnCollection_Click(object sender, EventArgs e)
        {
            CollectionPoint collectionForm = new CollectionPoint();
            collectionForm.Show();

            this.Hide();
        }
    }
}
